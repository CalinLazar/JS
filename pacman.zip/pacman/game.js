let pac_x = 1;
let pac_y = 1;

let coin1_x = Math.round(Math.random() * 9 + 1);
let coin1_y = Math.round(Math.random() * 9 + 1);

let coin2_x = Math.round(Math.random() * 9 + 1);
let coin2_y = Math.round(Math.random() * 9 + 1);

let coin3_x = Math.round(Math.random() * 9 + 1);
let coin3_y = Math.round(Math.random() * 9 + 1);

let coin4_x = Math.round(Math.random() * 9 + 1);
let coin4_y = Math.round(Math.random() * 9 + 1);




let bomb1_x = Math.round(Math.random() * 9 + 1)
let bomb1_y = Math.round(Math.random() * 9 + 1)

let bomb2_x = Math.round(Math.random() * 9 + 1)
let bomb2_y = Math.round(Math.random() * 9 + 1)

let bomb3_x = Math.round(Math.random() * 9 + 1)
let bomb3_y = Math.round(Math.random() * 9 + 1)

let bomb4_x = Math.round(Math.random() * 9 + 1)
let bomb4_y = Math.round(Math.random() * 9 + 1)

let bomb5_x = Math.round(Math.random() * 9 + 1)
let bomb5_y = Math.round(Math.random() * 9 + 1)





let score = 0;
let pacHP = 100

function action() {
  console.log(event.key);

  switch (event.key) {
    case "ArrowUp":
      pac_y--;
      break;
    case "ArrowDown":
      pac_y++;
      break;
    case "ArrowRight":
      pac_x++;
      break;
    case "ArrowLeft":
      pac_x--;
      break;
  }

  if(pac_x == coin1_x && pac_y == coin1_y){
    coin1_x = 0
    coin1_y = 0
  
    score +=25
    
  }

  if(pac_x == coin2_x && pac_y == coin2_y){
    coin2_x = 0
    coin2_y = 0
  
    score +=25
    
  }

  if(pac_x == coin3_x && pac_y == coin3_y){
    coin3_x = 0
    coin3_y = 0
  
    score +=25
    
  }

  if(pac_x == coin4_x && pac_y == coin4_y){
    coin4_x = 0
    coin4_y = 0
  
    score +=25
    
  }

  if(pac_x == bomb1_x && pac_y == bomb1_y){
    bomb1_x = 0
    bomb1_y = 0
  
    pacHP -=40
    
  }

  if(pac_x == bomb2_x && pac_y == bomb2_y){
    bomb2_x = 0
    bomb2_y = 0
  
    pacHP -=40
    
  }

  if(pac_x == bomb3_x && pac_y == bomb3_y){
    bomb3_x = 0
    bomb3_y = 0
  
    pacHP -=40
    
  }

  if(pac_x == bomb4_x && pac_y == bomb4_y){
    bomb4_x = 0
    bomb4_y = 0
  
    pacHP -=40
    
  }

  if(pac_x == bomb5_x && pac_y == bomb5_y){
    bomb5_x = 0
    bomb5_y = 0
  
    pacHP -=40
    
  }

  if(pacHP <= 0){
    alert("GAME OVER")
  }
  renderMap();

  if(score >= 100){
    alert("YOU WON")
  }
}


function renderMap() {
  gameMap.innerHTML = ``;
  for (let y = 1; y <= 10; y++) {
    for (let x = 1; x <= 10; x++) {
      if (x == pac_x && y == pac_y) {
        gameMap.innerHTML += `<div class="pac"></div>`;
      }
      else if(x == bomb1_x && y == bomb1_y){
        gameMap.innerHTML += `<div class="bomb"></div>`;
      }

      else if(x == bomb2_x && y == bomb2_y){
        gameMap.innerHTML += `<div class="bomb"></div>`;
      }

      else if(x == bomb3_x && y == bomb3_y){
        gameMap.innerHTML += `<div class="bomb"></div>`;
      }

      else if(x == bomb4_x && y == bomb4_y){
        gameMap.innerHTML += `<div class="bomb"></div>`;
      }

      else if(x == bomb5_x && y == bomb5_y){
        gameMap.innerHTML += `<div class="bomb"></div>`;
      }

      else if (x == coin1_x && y == coin1_y) {
        gameMap.innerHTML += `<div class="coin"></div>`;
      }

      else if (x == coin2_x && y == coin2_y) {
        gameMap.innerHTML += `<div class="coin"></div>`;
      }

      else if (x == coin3_x && y == coin3_y) {
        gameMap.innerHTML += `<div class="coin"></div>`;
      }

      else if (x == coin4_x && y == coin4_y) {
        gameMap.innerHTML += `<div class="coin"></div>`;
      }
    
       else {
        gameMap.innerHTML += `<div></div>`;
      }
    }
  }
  gameScore.innerHTML = `Score: ${score}`;

  pacHp.innerHTML = `PAC HP: ${pacHP}`


  if (pac_x > 10) {
    pac_x = 10;
    renderMap();
  }

  if (pac_x < 1) {
    pac_x = 1;
    renderMap();
  }

  if (pac_y > 10) {
    pac_y = 10;
    renderMap();
  }

  if (pac_y < 1) {
    pac_y = 1;
    renderMap();
  }
}
renderMap();
